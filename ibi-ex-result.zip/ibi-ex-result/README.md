Install: 
npm i

Run:
npm run dev

Tests
npm run test
