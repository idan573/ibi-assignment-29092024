export interface BusStop{
    in: number;
    out: number;
}